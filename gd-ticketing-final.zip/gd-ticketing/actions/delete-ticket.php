<?php include('../components/header.php'); ?>
<?php if(!$_SESSION['user'] && !$_SESSION['user_name']){
    header('Location: ../');
}

if($_GET['ticket_id'] && is_numeric($_GET['ticket_id'])){
    include ('../db/db_conn.php');
    $sql = "DELETE FROM messages WHERE unique_ticket_id='". $_GET['ticket_id'] ."'";
    $query = $conn->query($sql);
    if($query){
        header('Location: ../pages/home.php');
    }else{
        header('Location: ../pages/home.php');
        
    }
}
?>
<?php include('../components/footer.php'); ?>