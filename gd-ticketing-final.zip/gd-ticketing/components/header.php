<?php session_start(); ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>GD Ticketing</title>
  <meta name="description" content="Ticketing system - GD">
  <meta name="author" content="GD Ticketing">

  <link rel="stylesheet" href="../styles/styles.css">

</head>

<body>