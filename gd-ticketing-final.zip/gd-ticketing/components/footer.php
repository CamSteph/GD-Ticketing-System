<script defer type="text/javascript" link="./scripts/login-validation.js"></script>
<script defer type="text/javascript" link="./script.js"></script>
</body>
</html>